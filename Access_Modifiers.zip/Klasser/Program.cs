﻿using System;

namespace Klasser
{
    class Program
    {
        static void Main(string[] args)
        {
            Access_Modifiers.PPP Klassetest = new Access_Modifiers.PPP();
            Klassetest.Offentlig();

        }
    }
}
